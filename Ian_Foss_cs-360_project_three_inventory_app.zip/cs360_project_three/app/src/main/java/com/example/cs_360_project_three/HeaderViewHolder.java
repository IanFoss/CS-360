package com.example.cs_360_project_three;

import android.view.View;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

// Viewholder for header row of recyclerview
public class HeaderViewHolder extends RecyclerView.ViewHolder {

    public HeaderViewHolder(@NonNull View itemView) {
        super(itemView);
    }
}
